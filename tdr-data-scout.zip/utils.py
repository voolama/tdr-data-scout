# Utility functions placeholder
